class LinearAlgebra {

 transpose(a) {
    //verifica se a é uma matriz
    if(typeof a != "object" || !(a instanceof Matrix)) {
      throw "O parametro a deve ser uma matriz."
    }

    let c = new Matrix(a.cols, a.rows);

    for(let i = 1; i <= c.rows; i++) {
      for(let j = 1 ; j <= c.cols; j++ ) {
        c.set(i,j, a.get(j, i))
      }
    }
    return c 
  }

  plus(a,b) {
    // verificar se a e b são matrizes
    if(typeof b != "object" || !(b instanceof Matrix)||typeof a != "object" || !(a instanceof Matrix)) {
      throw "Os parametros a e b devem ser uma matriz."
    }

    //Verifica se as matrizes são iguais
    if(a.rows != b.rows || a.cols != b.cols) throw "As matrizes são incompatíveis."
    
    let c = new Matrix(a.rows, a.cols);

    for(let i = 1; i <= c.rows; i++) {
      for(let j = 1 ; j <= c.cols; j++ ) {
        c.set(i,j, a.get(i, j) + b.get(i, j))
      }
    }
    return c 

  }
  
  times(a, b) {

    //verifica se b é uma matriz
    if(typeof b != "object" || !(b instanceof Matrix)) {
      throw "O parametro b deve ser uma matriz."
    }

    let c = new Matrix(b.rows, b.cols);
    
    if(typeof a == "number"){      
      
      for(let i = 1; i <= c.rows; i++) {
        for(let j = 1 ; j <= c.cols; j++ ) {
          c.set(i,j, a * b.get(i, j))
        }
      }
    } else if(typeof a =='object' && a instanceof Matrix) {
      
      if(a.rows != b.rows || a.cols != b.cols) throw "As matrizes são incompatíveis."
      
      for(let i = 1; i <= c.rows; i++) {
        for(let j = 1 ; j <= c.cols; j++ ) {
          c.set(i,j, a.get(i, j) * b.get(i, j))
        }
      }
    } else {

      throw "O parâmetro a deve ser um escalar numérioco ou uma matriz."

    }
    return c 
  }

  div(a,b) {

    // verificar se a e b são matrizes
    if(typeof b != "object" || !(b instanceof Matrix)||typeof a != "object" || !(a instanceof Matrix)) {
      throw "Os parametros a e b devem ser uma matriz."
    }

    //verificar se as matrizes possuem o mesmo tamanho 
    if(a.rows != b.rows || a.cols != b.cols) {
      throw "As matrizes são incompatíveis."
    }

    // Verificar se a matriz b possui algum elemento nulo 
    for (let i = 0;i < b.values.lenght; i++) {
      if(b.values[i] == 0) {
        throw "A matiez b possui pelo menos um elemento nulo"
      }
    }

    let c = new Matrix(a.rows, a.cols);

    for(let i = 1; i <= c.rows; i++) {
      for(let j = 1 ; j <= c.cols; j++ ) {
        c.set(i,j, a.get(i, j) / b.get(i, j))
      }
    }
    return c 
  }

  dot(a,b){

    // verificar se a e b são matrizes
    if(typeof b != "object" || !(b instanceof Matrix)||typeof a != "object" || !(a instanceof Matrix)) {
      throw "Os parametros a e b devem ser uma matriz."
    }
    
    if(a.cols != b.rows){
      throw "O numero de colunas de a deve ser igual ao numero de linhas de b"
    }
    
    let c = new Matrix(a.rows, b.cols);

    for(let i = 1; i <= a.rows; i++) {
      for(let j = 1 ; j <= b.cols; j++ ) {
        let d = c.get(i,j)
        for(let k = 1 ; k <= a.cols; k++ ) { 
          d += a.get(i, k) * b.get(k, j)
        }
        c.set(i,j, d)
      }
    }
    return c
  }

  solve(a) {
    //verifica se a é uma matriz
    if(typeof a != "object" || !(a instanceof Matrix)) {
      throw "O parametro a deve ser uma matriz."
    }
    //verifica se o tamanho de a está correto 
    if(a.cols != (a.rows + 1)) {
      throw "O numero de colunas de (a) deve ser igual ao numero de linhas de (a) mais 1 "
    }
    //Separação da matriz a, em c e b
    let c = new Matrix(a.rows, a.cols -1)
    let b = new Vector(a.rows)
    let x = 0
    for (let i = 1;i < a.rows; i++) {
      for (let j = 1;j < a.cols; j++){
        c.set(i,j, a.get(i,j))
      }
    }
    
    for (let i = 1;i < a.rows; i++) {
      x = a.get(i, a.cols) 
      b.set(i,x)
    }

    // inicio do metodo
    let n = c.rows
    let d = 0
    let m = 0
    let y = 0
    let z = 0
    for (let k = 1; k < n ; k++) {
  
      for (let j = k+1; j <= n; j++){
        x = c.get(k,j)
        y = c.get(k,k)
        z = b.get(k)
        d = x / y 
        c.set(k,j, d)
        b.set(k, (z /y))
        c.set(k,k, 1)
      }
      for (let i = 1;i < n; i++) {
        if(i != k) {
          x = c.get(i,k)
          y = c.get(k,k)
          let m =  -x / y
          c.set(i,k, 0)
          for (let j = k+1; j < n ; j++) {
            x = c.get(k,j)
            y = c.get(i,j)
            z = m * x + y
            c.set(i,j, z)
          }
          x = b.get(k)
          y = b.get(i)
          z = m * x + y

          b.set(i,z)
          
          
        }
      }
    }
    return b
  }
}




